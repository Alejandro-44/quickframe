package model


/**
 * Transport company's truck.
 */
class Truck(
    val licensePlate: String, // Truck license plate.
    var capacity: Int,    // Truck capacity (in Kg).
    val consumption: Double    // Gasoline consumption of the truck (in gallons of gasoline per kilometer).
) {
    // -----------------------------------------------------------------
    // Attributes
    // -----------------------------------------------------------------

    /**
     * Current loading of the truck (in Kg).
     */
    var currentLoad: Int = 0

    // -----------------------------------------------------------------
    // Methods
    // -----------------------------------------------------------------

    /**
     * Load the truck with the load provided as a parameter.
     * Return true if the truck can be loaded (the load weight is less than the capacity).
     * If successful, assign the load weight to the capacity. Return false otherwise
     */
    fun load(loadWeight: Int): Boolean {
        val addedLoad = this.currentLoad + loadWeight
        var loaded = false
        if (addedLoad <= this.capacity) {
            this.currentLoad = addedLoad
            loaded = true
        }
        return loaded
    }

    /**
     * Unload the truck. In other words, the truck's load is set to zero.
     */
    fun unload() {
        this.currentLoad = 0
    }
}