package model

/**
 * Transport company.
 */
class TransportCompany {

    // -----------------------------------------------------------------
    // Attributes
    // -----------------------------------------------------------------

    /**
     * Truck 1.
     */
    private val truck1 = Truck("BAC213", 150, 85.0)

    /**
     * Truck 2.
     */
    private val truck2 = Truck("CAP384", 190, 70.0)

    /**
     * Truck 3.
     */
    private val truck3 = Truck("GER273", 280, 100.0)

    /**
     * Truck 4.
     */
    private val truck4 = Truck("JKV232", 215, 110.0)

    /**
     * Array of trucks
     */

    val trucks = arrayOf(truck1, truck2, truck3, truck4)

    // -----------------------------------------------------------------
    // Methods
    // -----------------------------------------------------------------

    /**
     * Load the truck with the given license plate with the load provided as a parameter.
     * Return true if the loading could be completed, false otherwise.
     */
    fun loadTruck(truckLicense: String, loadWeight: Int): Boolean {
        return when (truckLicense) {
            truck1.licensePlate -> truck1.load(loadWeight)
            truck2.licensePlate -> truck2.load(loadWeight)
            truck3.licensePlate -> truck3.load(loadWeight)
            truck4.licensePlate -> truck4.load(loadWeight)
            else -> {
                false
            }
        }
    }

    /**
     * Unload the truck with the license plate provided as a parameter.
     */
    fun unloadTruck(truckLicense: String) {
        when (truckLicense) {
            truck1.licensePlate -> truck1.unload()
            truck2.licensePlate -> truck2.unload()
            truck3.licensePlate -> truck3.unload()
            truck4.licensePlate -> truck4.unload()
            else -> {}
        }
    }

    /**
     * Return the total loading capacity of all trucks.
     * That is the sum of the capacities of the 4 trucks
     */
    fun getTotalCapacity(): Int {
        return truck1.capacity + truck2.capacity + truck3.capacity + truck4.capacity
    }

    /**
     * Return the total load of the trucks
     */
    fun getTotalLoad(): Int {
        return truck1.currentLoad + truck2.currentLoad + truck3.currentLoad + truck4.currentLoad
    }

    /**
     * Return the average load per truck.
     * That is, the total load divided by the number of trucks.
     */
    fun getAverageLoad(): Double {
        return getTotalLoad() / 4.0
    }

    /**
     * Return the best truck to transport the specified load.
     * The best truck is the one that has the capacity to load
     * the given load and also has the lowest gasoline consumption.
     * If no truck is suitable for the load, return null
     */
    fun getBestTruck(loadWeight: Int): Truck? {
        var bestTruck:Truck? = null
        var lowerConsumption = Double.MAX_VALUE

        for (truck in trucks) {
            if (truck.capacity >= loadWeight  && truck.consumption < lowerConsumption) {
                lowerConsumption = truck.consumption
                bestTruck = truck
            }
        }

        return bestTruck
    }

    /**
     * Return the license plate of the truck among the four trucks of
     * the transport company that has the largest current load.
     */
    fun truckMostLoadedLicensePlate(): String {
        var mostLoadedTruck: Truck = truck1

        for (truck in trucks) {
            if (truck.currentLoad > mostLoadedTruck.currentLoad) {
                mostLoadedTruck = truck
            }
        }

        return mostLoadedTruck.licensePlate
    }

    /**
     * Get and return how many trucks are unloaded.
     */
    fun quantityTrucksUnloaded(): Int {
        var counter = 0
        for (truck in trucks) {
            if (truck.currentLoad == 0) {
                counter++
            }
        }
        return counter
    }
}